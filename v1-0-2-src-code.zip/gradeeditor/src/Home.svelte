<script>
    export let classes
    import { createEventDispatcher } from 'svelte'
    const dispatch = createEventDispatcher()

	function getGradeFromClass(details){
        let text = ""
		for(let term of details){
			if(term.task.progressScore != undefined){
				text = term.task.progressScore + " (" + term.task.progressPercent + "%)"
			}
		}
        return text
	}

	function openEditor(index){
        dispatch('message', {m: "openEditor", data: classes[index]})
	}
</script>

{#each classes as cl, i}
    <button on:click={() => openEditor(i)} style="padding: 5 !important">
        <strong>{cl.details[0].task.courseName}</strong> {getGradeFromClass(cl.details)}
    </button>
{/each}